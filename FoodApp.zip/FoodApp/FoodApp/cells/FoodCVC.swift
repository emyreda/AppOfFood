//
//  FoodCVC.swift
//  FoodApp
//
//  Created by Mac on 7/3/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class FoodCVC: UICollectionViewCell {
    

    
    @IBOutlet weak var imagefood: UIImageView!
    @IBOutlet weak var nameFood: UILabel!
    
    
    /*
    func setfood(food:Food){
        
        
        nameFood.text = food.name!
        imagefood.image = UIImage(named:food.image!)
        
        
        
        
    }
    */
}
