//
//  FoodItem.swift
//  FoodApp
//
//  Created by Mac on 7/3/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import Foundation
import UIKit

class Food {
    
    var name:String?
    var des:String?
    var image:String?
    
    init(img:String ,name:String , des:String) {
        self.name.self = name
        self.des.self = des
        self.image.self = img

    }
    
    
    
}
